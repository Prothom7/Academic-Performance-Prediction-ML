# System Architecture

## 1. Data layer

**Input:** raw 32-column survey CSV.

**Output:** standardized 24-column modeling dataset containing 23 predictors and
the `Year1CGPA` class.

## 2. Split layer

A fixed `random_state=1` and class stratification generate:

- Train: 70%
- Validation: 15%
- Test: 15%

## 3. Preprocessing layer

- Numeric: `HSCGraduationYear` passed through as numeric.
- Categorical: one-hot encoding with unknown-category handling.
- The encoder is fitted only on the data used to fit each model.

## 4. Training/validation layer

RandomForest candidates are fitted on Train and compared on Validation.
Weighted F1 is the primary selection criterion.

## 5. Model-locking layer

The selected hyperparameters are frozen before test evaluation.

## 6. Final training layer

Train and Validation are combined and the preprocessing + RandomForest
pipeline is refitted.

## 7. Test/evaluation layer

The locked model predicts the held-out Test split. The project reports:

- Accuracy
- Weighted Precision
- Weighted Recall
- Weighted F1
- Macro F1
- Cohen's Kappa
- Weighted and macro ROC-AUC
- Weighted and macro PRC-AUC
- Class-wise report
- Confusion matrix

## 8. Model artifact

The complete scikit-learn preprocessing/model pipeline is serialized with
Joblib so prediction uses exactly the same transformation learned during
training.
