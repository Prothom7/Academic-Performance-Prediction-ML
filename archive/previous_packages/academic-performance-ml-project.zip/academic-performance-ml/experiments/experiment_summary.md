# Experiment Summary

## Dataset

- Relation: E1_Year1CGPA_FinalClean
- Instances: 3,516
- Modeling attributes: 24
- Predictors: 23
- Target: Year1CGPA
- Classes: 5

## Broad WEKA benchmark

A broad set of baselines, Bayesian methods, linear models, SVM, neural
networks, decision trees, ensembles, instance-based methods, rule learners,
and meta-classifiers was evaluated using 10-fold cross-validation.

Important reference results:

| Model | Accuracy |
|---|---:|
| ZeroR | 28.0148% |
| OneR | 32.7929% |
| BayesNet | 34.5848% |
| SMO | 33.9022% |
| MultilayerPerceptron | 56.0011% |
| J48 | 52.6451% |
| RandomForest baseline | 60.3242% |
| RandomCommittee | 58.2480% |
| IBk | 57.2810% |
| KStar | 58.0489% |
| LMT | 58.1342% |

## RandomForest tuning

### RF-T01 — number of trees

- 250 trees selected
- Accuracy: 60.7509%
- Weighted F1: 0.608

### RF-T02 — number of features (`K`)

- K=2 selected
- Accuracy: 60.6086%
- Weighted F1: 0.605

### RF-T03 — minimum leaf weight (`M`)

- M=3 selected
- Accuracy: **60.9499%**
- Weighted F1: **0.609**
- Kappa: **0.4928**

This was the strongest WEKA development-stage RandomForest result.

## Feature analysis

### RandomForest impurity importance

Highest-ranked features included:

- CurrentInstitution
- MotherEducation
- FatherEducation
- CollegeAttendance
- UniversityPreferenceOrder
- DepartmentPreferenceOrder

### Information Gain

Top four:

1. HSCMath
2. CurrentInstitution
3. HSCPhysics
4. HSCChemistry

### CFS + BestFirst

Selected exactly four:

- CurrentInstitution
- HSCMath
- HSCPhysics
- HSCChemistry

### FS-E01 — leakage-controlled feature-selection test

CFS + BestFirst was placed inside the cross-validation pipeline and combined
with internally tuned RandomForest.

- Accuracy: 36.6894%
- Weighted F1: 0.351
- Kappa: 0.1739

Compared with the full tuned RandomForest (60.9499%), aggressive feature
selection reduced accuracy by approximately **24.26 percentage points**.

Interpretation: the four selected predictors contain strong direct signal, but
the nonlinear forest benefits from weaker contextual predictors and feature
interactions across the broader feature set.

## Final Python pipeline

A fixed stratified 70/15/15 split was created:

- Train: 2,461
- Validation: 527
- Test: 528

Validation selected:

- 100 trees
- max_features = sqrt
- min_samples_leaf = 1

Final model was refitted on Train+Validation (2,988 rows) and evaluated on the
528-row held-out test split.

### Final test

- Accuracy: **59.85%**
- Weighted Precision: **62.02%**
- Weighted Recall: **59.85%**
- Weighted F1: **59.84%**
- Macro F1: **60.33%**
- Cohen's Kappa: **0.4811**
- Weighted ROC-AUC: **0.862**
- Weighted PRC-AUC: **0.715**

## Methodological limitation

The entire dataset had already been explored in WEKA before the final
70/15/15 split was established. The final test is therefore held out from the
coded training/tuning pipeline, but was not prospectively isolated before all
exploratory work.
