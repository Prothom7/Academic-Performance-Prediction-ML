# Academic Performance Prediction — Machine Learning Project

A reproducible multiclass machine-learning pipeline for predicting **first-year
university CGPA category (`Year1CGPA`)** from pre-university, institutional,
family, socioeconomic, and preference-related survey variables.

## Final problem setup

- Instances: **3,516**
- Predictors: **23**
- Target: **Year1CGPA**
- Target classes: **5**
- Final evaluation design: **70% Train / 15% Validation / 15% Test**
- Split type: **stratified**
- Random seed: **1**
- Final model family: **RandomForest**

## Architecture

```text
Raw 32-column survey
        |
        v
Cleaning + leakage-aware/irrelevant-field removal
        |
        v
24-column modeling table
(23 predictors + Year1CGPA)
        |
        v
Stratified 70 / 15 / 15 split
   /          |          \
Train     Validation      Test
   \          /
    \        /
RandomForest tuning
(weighted F1 primary)
        |
        v
Lock hyperparameters
        |
        v
Refit on Train + Validation
        |
        v
One-time held-out Test evaluation
        |
        v
Accuracy / Precision / Recall / F1 / Kappa
ROC-AUC / PRC-AUC / Confusion Matrix
```

## Preprocessing

The raw survey contains 32 fields. For the first-year CGPA prediction problem,
the pipeline removes:

1. Timestamp
2. Second-year CGPA
3. Current university living arrangement
4. Current part-time employment
5. Current university-period monthly expenditure
6. Primary financial-support source
7. Student-club membership
8. Research participation

The modeling table contains 23 predictors and the `Year1CGPA` target.

`HSCGraduationYear` is treated as numeric. Remaining predictors are categorical
and are converted using `OneHotEncoder(handle_unknown="ignore")`.

## Train / Validation / Test protocol

The 3,516 records are split using stratification on `Year1CGPA`:

- Train: 2,461
- Validation: 527
- Test: 528

The test split is not used for model selection in the coded pipeline.

## RandomForest tuning

Candidate settings:

- Trees: 100, 250, 500
- Max features: sqrt, 2, 4
- Minimum samples per leaf: 1, 2, 3

Selection rule:

1. Highest weighted F1
2. Accuracy as first tie-breaker
3. Cohen's Kappa as second tie-breaker

Selected validation configuration:

- `n_estimators=100`
- `max_features="sqrt"`
- `min_samples_leaf=1`

## Final held-out test results

| Metric | Result |
|---|---:|
| Accuracy | 0.5985 |
| Weighted Precision | 0.6202 |
| Weighted Recall | 0.5985 |
| Weighted F1 | 0.5984 |
| Macro F1 | 0.6033 |
| Cohen's Kappa | 0.4811 |
| Weighted ROC-AUC | 0.862 |
| Weighted PRC-AUC | 0.715 |

## How to run

```bash
pip install -r requirements.txt
python main.py
```

Running `main.py` reproduces cleaning, splitting, validation tuning, final model
training, test evaluation, result files, and the saved model.

## Important methodological note

Before this coded 70/15/15 protocol was created, the full dataset had already
been explored in WEKA. Therefore, the 528-row test set is a held-out test for
the **final coded pipeline**, but it was not prospectively reserved before all
earlier exploratory analyses. This limitation should be disclosed in the final
report.

## WEKA experimental context

A broad WEKA classifier sweep was performed before the final coded pipeline.
The strongest development-stage model was a tuned RandomForest. Feature
selection using CFS + BestFirst reduced performance substantially, indicating
that the full RandomForest benefited from contextual predictors beyond the
small four-feature core.

See `experiments/experiment_summary.md`.
